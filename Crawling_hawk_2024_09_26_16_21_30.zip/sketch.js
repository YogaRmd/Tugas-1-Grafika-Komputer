function setup() {
  createCanvas(640, 480);
  background(128,0,0);
  
  let cx = width / 2;  // Koordinat x pusat
  let cy = height / 2; // Koordinat y pusat
  let radiusOuter = 150; // Radius lingkaran luar (untuk titik luar)
  let radiusInner = 75;  // Radius lingkaran dalam (untuk titik dalam)
  let points = 8;       // Jumlah titik sudut octagram

  // Mulai menggambar bentuk octagram
  beginShape();
  for (let i = 0; i < points * 2; i++) {
    // Hitung sudut
    let angle = PI / points * i;
    
    // Ganti antara radius luar dan dalam setiap titik
    let r = i % 2 === 0 ? radiusOuter : radiusInner;
    
    // Hitung koordinat titik
    let x = cx + cos(angle) * r;
    let y = cy + sin(angle) * r;
    
    vertex(x, y);  // Tetapkan titik ke bentuk
  }
  endShape(CLOSE);  // Tutup bentuk
}
